//
//  BuildsTableViewCell.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 9/3/21.
//

import UIKit

protocol BuildsTableViewCellDelegate: AnyObject {
    func itemButtonTapped(button: Int, cell: BuildsTableViewCell)
    
}

class BuildsTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var itemTwoButton: UIButton!
    @IBOutlet weak var itemOneButton: UIButton!
    @IBOutlet weak var itemThreeButton: UIButton!
    @IBOutlet weak var itemFourButton: UIButton!
    @IBOutlet weak var itemFiveButton: UIButton!
    @IBOutlet weak var itemSixButton: UIButton!
    
    //MARK: - Properties
    var build: Build? {
        didSet {
            updateViews()
        }
    }
    
    
    weak var delegate: BuildsTableViewCellDelegate?
    
    var itemButtons: [UIButton] {
        return [itemOneButton, itemTwoButton, itemThreeButton, itemFourButton, itemFiveButton, itemSixButton]
    }
    
    //MARK: - Actions
    @IBAction func itemButtonTapped(_ sender: UIButton) {
        delegate?.itemButtonTapped(button: sender.tag, cell: self)
        
        //create a protocol delegate
        
        //delegate._____ name of protocol
        
        //make table view conform to delegate
        
        //pass in
        
    }
    
    
    //MARK: - helper funcs

    func updateViews() {
        guard let build = build else { return }
        if let itemOne = build.itemOne {
            itemOneButton.setImage(itemOne, for: .normal)
        }
        
        if let itemTwo = build.itemTwo {
            itemTwoButton.setImage(itemTwo, for: .normal)
        }
        
        if let itemThree = build.itemThree {
            itemThreeButton.setImage(itemThree, for: .normal)
        }
        
        if let itemFour = build.itemFour {
            itemFourButton.setImage(itemFour, for: .normal)
        }
        
        if let itemFive = build.itemFive {
            itemFiveButton.setImage(itemFive, for: .normal)
        }
        
        if let itemSix = build.itemSix {
            itemSixButton.setImage(itemSix, for: .normal)
        }
        
        nameLabel.text = build.title
    }//end of func
    
}

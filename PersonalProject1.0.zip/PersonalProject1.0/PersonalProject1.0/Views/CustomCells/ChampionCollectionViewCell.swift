//
//  ChapionCollectionViewCell.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 8/22/21.
//

import UIKit

class ChampionCollectionViewCell: UICollectionViewCell {

    
    //MARK: - Outlets
    
    @IBOutlet weak var championImageView: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    var champions: ChampionInfo? {
        didSet {
            updateViews()
        }
    }
    
    func updateViews() {
        guard let champion = champions else { return }
        
        let underlineAttriString = NSAttributedString(string: champion.name,
                                                  attributes: [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
            nameLabel.attributedText = underlineAttriString
        nameLabel.textColor = .white
        nameLabel.highlightedTextColor = .black
        
        ChampionController.fetchImageFor(championInfo: champion) { result in
            DispatchQueue.main.async {
                switch result {
                
                case .success(let image):
                    self.championImageView.image = image
                    self.championImageView.layer.cornerRadius = self.frame.height / 4.0
                    self.championImageView.layer.shadowColor = UIColor.black.cgColor
                    self.championImageView.layer.shadowOffset = CGSize(width: 0, height: 2.0)
                    self.championImageView.layer.shadowRadius = 50.0
                    self.championImageView.layer.shadowOpacity = 1

                case .failure(_):
                    self.championImageView.image = UIImage(systemName: "square")
                }
            }
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        championImageView.image = UIImage(systemName: "square")
    }
    
    

}




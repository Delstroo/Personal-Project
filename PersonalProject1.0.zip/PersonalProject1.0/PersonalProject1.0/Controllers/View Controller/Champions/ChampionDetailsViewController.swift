//
//  ChampionDetailsViewController.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 8/22/21.
//

import UIKit

class ChampionDetailsViewController: UIViewController {
    
    //MARK: - Landing Pad
    var champion: ChampionInfo?
    
    //MARK: - Outlets
    @IBOutlet weak var championImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var blurbLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateViews()
        
    }//end of func
    
    func updateViews() {
        guard let champions = champion else { return }
        
        let underlineAttriString = NSAttributedString(string: champions.name,
                                                      attributes: [NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue])
        nameLabel.attributedText = underlineAttriString
        titleLabel.text = champions.title
        blurbLabel.text = champions.blurb
        
        nameLabel.textColor = .white
        titleLabel.textColor = .white
        blurbLabel.textColor = .white
        
        ChampionController.fetchImageFor(championInfo: champions) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let full):
                    self.championImageView.image = full
                case .failure(_):
                    self.championImageView.image = UIImage(systemName: "Square")
                }
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toStatsVC" {
            
           guard let destination = segue.destination as? ChampionStatsViewController else { return }
            
            let statScreen = champion
            destination.champion = statScreen
            
        }
        
    }
    
}//end of class

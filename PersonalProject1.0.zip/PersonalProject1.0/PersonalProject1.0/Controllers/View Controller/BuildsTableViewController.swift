//
//  BuildsTableViewController.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 9/3/21.
//

import UIKit

class BuildsTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    //MARK: - Actions
    
    @IBAction func addBuildButtonTapped(_ sender: Any) {
        BuildController.buildInstance.createBuild(title: "Hollo")
        tableView.reloadData()
        
    }
    
    
    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return BuildController.buildInstance.builds.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "buildCell", for: indexPath) as? BuildsTableViewCell else { return UITableViewCell() 	}
        
        let build = BuildController.buildInstance.builds[indexPath.row]
        
        cell.build = build
        cell.delegate = self
        
        return cell
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    func presentItemCollectionVC(button: Int, cell: BuildsTableViewCell) {
        DispatchQueue.main.async {
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            guard let viewController = storyboard.instantiateViewController(identifier: "ItemCollection") as? ItemsCollectionViewController else { return }
            viewController.modalPresentationStyle = .automatic
            viewController.delegate = self
            viewController.button = button
            viewController.cell = cell
            viewController.isModallyPresented = true
            self.present(viewController, animated: true)
        }
    }//end of func
    
    
    func presentBuildAlertController(for build: Build?) {
        
        let alertController = UIAlertController(title: "Add build name.", message: "", preferredStyle: .alert)
        alertController.addTextField { (textField) in
            textField.placeholder = "Enter build name here..."
            textField.autocapitalizationType = .sentences
            textField.autocorrectionType = .no
            if let build = build {
                textField.text = build.title
            }
            
        }
        
        let addAction = UIAlertAction(title: "Send", style: .default) { (_) in
            guard let body = alertController.textFields?.first?.text, !body.isEmpty else { return }
    
        }
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        
        alertController.addAction(addAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)

    }
    
    
}//end of class

extension BuildsTableViewController: BuildsTableViewCellDelegate {
    func itemButtonTapped(button: Int, cell: BuildsTableViewCell) {
        
        presentItemCollectionVC(button: button, cell: cell)
        
    }
    
}

extension BuildsTableViewController: ItemCollectionViewControllerDelegate {
    func itemIsSelected(item: Items, button: Int, cell: BuildsTableViewCell, itemImage: UIImage) {
        
        // guard let itemButton = cell.itemButtons.first(where: { $0.tag == button }) else { return }
        
        guard let build = cell.build else { return }
        
        switch button {
        case 1:
            build.itemOne = itemImage
        case 2:
            build.itemTwo = itemImage
        case 3:
            build.itemThree = itemImage
        case 4:
            build.itemFour = itemImage
        case 5:
            build.itemFive = itemImage
        case 6:
            build.itemSix = itemImage
            
        default:
            print("Bad button.")
        }
        
        // itemButton.setImage(itemImage, for: .normal)
        tableView.reloadData()
        BuildController.buildInstance.updateBuild(build: build)
    }//end of func

}

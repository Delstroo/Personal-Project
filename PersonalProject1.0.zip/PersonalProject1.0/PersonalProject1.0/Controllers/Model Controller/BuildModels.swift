//
//  BuildModels.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 9/9/21.
//

import UIKit

class BuildController {
    
    //SOT
    var builds: [Build] = []
    
    //Properties
    static let buildInstance = BuildController()
    
    
    //fetch build
    
    
    //create build
    func createBuild(title: String) {
        
        let newBuild = Build(title: title)
        builds.append(newBuild)
        
    }
    
    //update build
    func updateBuild(build: Build) {
        
    /*    build.itemOne = itemOne
        build.itemTwo = itemTwo
        build.itemThree = itemThree
        build.itemFour = itemFour
        build.itemFive = itemFive
        build.itemSix = itemSix
        
        */
        print("updateBuild")
    }
    
    //delete build
    func deleteBuild(build: Build) {
        
    }
    
    
    
    
}

//
//  ChampionsInfo.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 8/22/21.
//

import Foundation

struct TopLevelObject: Codable {
    let data: [String: ChampionInfo]
}

struct ChampionInfo: Codable {
    let name: String
    let title: String
    let blurb: String
    let image: ChampionImage
    var stats: ChampionStats
}

struct ChampionImage: Codable {
    let full: String
    let sprite: String
}

struct ChampionStats: Codable {
    var hp: Double
    let hpperlevel: Double
    let mp: Double
    let mpperlevel: Double
    let movespeed: Double
    let armor: Double
    let armorperlevel: Double
    let spellblock : Double
    let spellblockperlevel: Double
    let attackrange: Double
    let hpregen: Double
    let hpregenperlevel: Double
    let mpregen: Double
    let mpregenperlevel: Double
    let crit: Double
    let critperlevel: Double
    let attackdamage: Double
    let attackdamageperlevel: Double
    let attackspeedperlevel: Double
    let attackspeed: Double
    
}

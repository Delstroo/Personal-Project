//
//  Builds.swift
//  PersonalProject1.0
//
//  Created by Delstun McCray on 9/9/21.
//

import UIKit

class Build {
    
    var title: String
    var itemOne: UIImage?
    var itemTwo: UIImage?
    var itemThree: UIImage?
    var itemFour: UIImage?
    var itemFive: UIImage?
    var itemSix: UIImage?
    
    init(title: String, itemOne: UIImage? = nil, itemTwo: UIImage? = nil, itemThree: UIImage? = nil, itemFour: UIImage? = nil, itemFive: UIImage? = nil, itemSix: UIImage? = nil) {
        
        self.title = title
        self.itemOne = itemOne
        self.itemTwo = itemTwo
        self.itemThree = itemThree
        self.itemFour = itemFour
        self.itemFive = itemFive
        self.itemSix = itemSix
    }
    
}
